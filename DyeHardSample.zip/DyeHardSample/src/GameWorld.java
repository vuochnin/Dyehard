import dyehard.Updateable;
import dyehard.Enums.ManagerStateEnum;

public class GameWorld implements Updateable {

    @Override
    public void update() {
        // TODO Auto-generated method stub

    }

    @Override
    public void setSpeed(float factor) {
        // TODO Auto-generated method stub

    }

    @Override
    public ManagerStateEnum updateState() {
        // TODO Auto-generated method stub
        return null;
    }

}
