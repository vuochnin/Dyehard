/*
 * 
 */
package dyehard.World;

public class GameState {
    
    public static int Score = 0;
    public static int RemainingLives = 4;
    public static int DistanceTravelled = 0;
    public static int TargetDistance = 0;
}
