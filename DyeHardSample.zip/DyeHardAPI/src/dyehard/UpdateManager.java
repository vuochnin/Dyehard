package dyehard;

import java.util.HashSet;
import java.util.Set;

import dyehard.Enums.ManagerStateEnum;

public class UpdateManager {
    
	private static UpdateManager instance;
	
	static {
		instance = new UpdateManager();
	}
    private boolean speedUp = false;

    private Set<Updateable> gameObjects;
    private Set<Updateable> newlyRegisteredObjects;
    
    public static UpdateManager getInstance() {
    	return instance;
    }
    
    public void setSpeedUp(boolean isSpeedUp) {
    	speedUp = isSpeedUp;
    }
    
    public boolean getSpeedUp() {
    	return speedUp;
    }
    
    private UpdateManager() {
    	gameObjects = new HashSet<Updateable>();
    	newlyRegisteredObjects = new HashSet<Updateable>();
    }

    /**
     * Update.
     */
    public void update() {
        for (Updateable o : gameObjects) {
            if (o != null && o.updateState() == ManagerStateEnum.ACTIVE) {
                o.update();
                if (speedUp) {
                    o.setSpeed(10f);
                } else if (!speedUp) {
                    o.setSpeed(0.1f);
                }
            }
        }

        gameObjects.addAll(newlyRegisteredObjects);
        newlyRegisteredObjects.clear();

        Set<Updateable> destroyed = new HashSet<Updateable>();
        for (Updateable o : gameObjects) {
            if (o == null || o.updateState() == ManagerStateEnum.DESTROYED) {
                destroyed.add(o);
            }
        }

        gameObjects.removeAll(destroyed);
    }

    /**
     * Register.
     *
     * @param o is the object to be registered
     */
    public void register(Updateable o) {
        if (o != null) {
            newlyRegisteredObjects.add(o);
        }
    }
}
