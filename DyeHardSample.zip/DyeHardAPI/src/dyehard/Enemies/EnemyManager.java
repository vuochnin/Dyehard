package dyehard.Enemies;

import java.util.ArrayList;
import java.util.List;

public class EnemyManager {
	
	private static EnemyManager instance;
    private List<Enemy> enemies;
	
	static {
		instance = new EnemyManager();
	}
	
	public static EnemyManager getInstance() {
		return instance;
	}

    private EnemyManager() {
    	enemies = new ArrayList<Enemy>();
    }

    /**
     * Register enemy.
     *
     * @param e the e
     */
    public void registerEnemy(Enemy e) {
        e.initialize();
        enemies.add(e);
    }

    /**
     * Clear.
     */
    public void clear() {
        for (Enemy e : enemies) {
            e.destroy();
        }
        enemies.clear();
    }

    /**
     * Gets the enemies.
     *
     * @return the enemies
     */
    public List<Enemy> getEnemies() {
        return enemies;
    }
}
