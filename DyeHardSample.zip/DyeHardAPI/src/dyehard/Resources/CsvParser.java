package dyehard.Resources;

public interface CsvParser {
	
	/**
	 * Parses the data.
	 *
	 * @param data is file path to be parsed
	 */
	public void parseData(String data);
}
