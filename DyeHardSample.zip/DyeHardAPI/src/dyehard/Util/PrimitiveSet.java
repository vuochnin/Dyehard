/*
 * 
 */
package dyehard.Util;

import java.util.ArrayList;
import java.util.List;

import Engine.Primitive;

public class PrimitiveSet {
    
    protected List<Primitive> primitives;

    /**
     * Instantiates a new primitive set.
     */
    public PrimitiveSet() {
        primitives = new ArrayList<Primitive>();
    }

    /**
     * Adds the primitive.
     *
     * @param primitive the primitive to add to the set
     */
    public void addPrimitive(Primitive primitive) {
        if (primitive != null) {
            primitives.add(primitive);
        }
    }

    /**
     * Destroy all.
     */
    public void destroyAll() {
        for (Primitive p : primitives) {
            p.destroy();
        }
    }
}
