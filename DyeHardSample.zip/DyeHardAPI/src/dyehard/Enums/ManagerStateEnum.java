package dyehard.Enums;

public enum ManagerStateEnum {
    ACTIVE, INACTIVE, DESTROYED,
}
