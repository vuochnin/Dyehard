package dyehard.Enums;

public enum HeroID {
    HERO_JET_SPEED, HERO_SPEED_LIMIT, HERO_DRAG,
}
