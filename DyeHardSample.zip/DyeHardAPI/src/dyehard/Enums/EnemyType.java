package dyehard.Enums;

public enum EnemyType {
    PORTAL_ENEMY, PORTAL_SPAWN, SHOOTING_ENEMY, COLLECTOR_ENEMY, CHARGER_ENEMY
}
