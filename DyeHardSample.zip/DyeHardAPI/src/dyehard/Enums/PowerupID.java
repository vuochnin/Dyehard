package dyehard.Enums;

public enum PowerupID {
    PU_GHOST, PU_GRAVITY, PU_INVINCIBILITY, PU_MAGNETISM, PU_SLOWDOWN, PU_SPEEDUP, PU_UNARMED,
}
