/*
 * 
 */
package dyehard.Collectibles;

public class PowerUpMeter {
}
