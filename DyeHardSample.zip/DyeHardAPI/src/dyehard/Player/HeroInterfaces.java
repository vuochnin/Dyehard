package dyehard.Player;

import Engine.Primitive;
import dyehard.Collision.CollidableGameObject;

public class HeroInterfaces {
    
    public interface HeroCollision {
        
        /**
         * Collide with hero.
         *
         * @param hero to check collision with other
         * @param other to check collision with actor
         */
        public abstract void collideWithHero(Hero hero, CollidableGameObject other);
    }

    public interface HeroDamage {
        
        /**
         * Damage hero.
         *
         * @param hero to take damage
         * @param who is how much damage to take
         */
        public void damageHero(Hero hero, Primitive who);
    }
}
