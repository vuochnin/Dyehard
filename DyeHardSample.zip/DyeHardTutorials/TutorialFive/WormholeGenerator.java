package TutorialFive;

public class WormholeGenerator {

}
